This folder contains a sample updatable Tunnelblick configuration.

It contains a dummy .ovpn file and dummy ca.crt, client.crt, etc. files, but it is not
a real VPN configuration and will not connect to any VPN.

You can use this sample as a model and make modifications as you wish for your
own situation. Of course you will need to host the update files on your own website,
and make modifications to the URLs in the sample accordingly.

To use this as-is (which contacts tunnelblick.net for update info), do the following:

   1. Install Tunnelblick

   2. Double-click the following configuration:

      Original config that will be updated/Updatable Config 001.tblk

   3. Enter your admin credentials to install an updatable configuration which includes one
      configuration named “VPN-Config”. (The example configuration will be installed as a
      “private” configuration automatically because of entries in its Info.plist.)

      You will almost immediately be presented with a new window asking if you want to
      update the configuration.

      DO NOT CLICK ANYTHING -- DO NOT INSTALL THE UPDATE (YET).

   4. Move the window out of the way, and then examine the .ovpn file (use Tunnelblick’s
      “gear” menu below the list of configurations in the VPN” Details” window), and you
      will see that it is version 1.0.0.

   5. Now click “Install Update” in the window you moved aside earlier. The update will
      be downloaded and then a new window will appear. Click “Install and Relaunch” and
      enter your admin credentials to install the updated updatable configuration. You
      will then need to enter your credentials again to install the new version of the
      “VPN-Config” configuration.

      Note: admin credentials are asked for twice: once to install the updatable .tblk
            (which may contain many configurations), then a second time to install the
            actual configuration(s) in the updatable .tblk.

   6. If you now examine the .ovpn file, you will see that the configuration is now
      version 1.0.1.

