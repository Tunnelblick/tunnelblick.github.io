#!/bin/bash
export PATH="/bin:/sbin:/usr/sbin:/usr/bin"

osascript -e 'tell application "Tunnelblick"' -e 'activate' -e 'end tell'
